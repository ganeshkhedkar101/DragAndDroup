
import Loader from './Loader'
import NoDataFound from './NoDataFound'
import Product from './Product'
import Popup from './popUP'

export {
  Loader,
  NoDataFound,
  Product,
  Popup
}
